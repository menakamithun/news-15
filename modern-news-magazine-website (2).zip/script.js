/* ==========================================================================
   NEWS & MAGAZINE MAIN JAVASCRIPT WITH LIVE LOCALSTORAGE CMS
   ========================================================================== */

// Initial Seed Database
const DEFAULT_ARTICLES = [
  {
    id: 1,
    title: "The Future of Artificial Intelligence: Generative Models Redefining Industries",
    excerpt: "As generative AI moves beyond text and images into video and multi-agent systems, we explore how enterprise workflows are shifting permanently in 2026.",
    category: "Technology",
    author: "Sarah Jenkins",
    authorAvatar: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150",
    authorBio: "Senior technology editor with over a decade of experience analyzing tech trends, automation, and artificial intelligence.",
    date: "May 12, 2026",
    readTime: "6 min read",
    image: "https://images.unsplash.com/photo-1677442136019-21780efad99a?w=800",
    views: 15420,
    trending: true,
    editorsPick: true,
    content: `
      <p>The landscape of Artificial Intelligence has undergone a seismic shift. What started as a playground for text generation and image creation in the early 2020s has matured into a robust network of collaborative agents reshaping global commerce, logistics, and manufacturing in 2026.</p>
      
      <h2>The Rise of Multi-Agent Autonomous Systems</h2>
      <p>Rather than single prompts yielding isolated responses, modern AI systems rely on specialized agents that negotiate and collaborate with each other. For example, a software engineering agent can work directly with a quality assurance agent and an operations manager agent to build, test, and deploy products autonomously.</p>
      <blockquote>"The true value of generative AI isn't in replacing human creativity, but in creating digital co-pilots that take care of repetitive complexity." — Dr. Elena Vance, AI Ethics Institute</blockquote>
      
      <h2>Real-World Impact Across Industries</h2>
      <p>In healthcare, AI-guided diagnostic assistants are analyzing combined data feeds from medical imaging, genetic testing, and wearable device history. By cross-referencing millions of cases globally, these tools have improved diagnostic speed for rare cardiovascular conditions by over 40%.</p>
      
      <h3>Key Transformations in 2026:</h3>
      <ul>
        <li><strong>Finance:</strong> Algorithmic trading systems powered by predictive sentiment models mitigate risks in volatile markets.</li>
        <li><strong>Entertainment:</strong> Localized real-time voice and lip-sync translation allow independent movies to reach global audiences immediately.</li>
        <li><strong>Retail:</strong> hyper-personalized supply chain management forecasts demand down to individual neighborhoods.</li>
      </ul>
      
      <h2>Ethical Frontiers and the Regulation Paradox</h2>
      <p>As deepfakes reach complete indistinguishability from reality, developers and governments are deploying decentralized cryptography and watermarking protocols. Yet, the challenge remains: how to foster rapid technological innovation while protecting the integrity of the digital public square. The upcoming global summit on AI safety is expected to draft enforceable standards for multi-agent accountability.</p>
    `
  },
  {
    id: 2,
    title: "Global Markets Adapt to Shift in Green Energy Finance Infrastructure",
    excerpt: "A major injection of capital into next-generation geothermal and fusion infrastructure is resetting bond markets and stock exchanges across European capitals.",
    category: "Business",
    author: "David Thorne",
    authorAvatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150",
    authorBio: "Financial analyst and international correspondent covering macroeconomic policy and sustainable investing systems.",
    date: "May 10, 2026",
    readTime: "5 min read",
    image: "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800",
    views: 12800,
    trending: true,
    editorsPick: false,
    content: `
      <p>Corporate finance is redirecting flows at a pace never seen before. As solar and wind energy reach maturity, major investment firms are locking their sights on the ultimate frontier of energy security: deep geothermal power plants and pilot-scale commercial fusion cells.</p>
      
      <h2>The Capital Influx</h2>
      <p>A consortium of European sovereign funds recently announced a €45 billion green bond issuance focused solely on retrofitting old mining sites and oil rigs for geothermal heat extraction. This represents the single largest clean energy fund ever launched.</p>
      <blockquote>"Sustainable investments are no longer just compliance targets; they are the primary engine of alpha in modern portfolio management."</blockquote>
      
      <h2>Sovereign Bonds React</h2>
      <p>Yield curves on conventional energy infrastructure have begun to steepen as long-term investors seek protection from carbon penalty taxation. Countries leading the thermal-transition framework are enjoying historical credit rating upgrades, signaling a complete rewiring of international balance sheets.</p>
    `
  },
  {
    id: 3,
    title: "Exploring the Remote Wilderness of South America's Patagonian Fjords",
    excerpt: "A premium deep-dive into ecotourism trends, showcasing the fragile beauty of the southern coastlines and the local conservation initiatives leading the charge.",
    category: "World",
    author: "Maria Alvarez",
    authorAvatar: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150",
    authorBio: "Travel photojournalist and environmental advocate documenting global wilderness regions and local cultures.",
    date: "May 08, 2026",
    readTime: "8 min read",
    image: "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=800",
    views: 9500,
    trending: false,
    editorsPick: true,
    content: `
      <p>The Patagonian fjords are a labyrinth of deep valleys flooded by the sea, where glaciated mountains plunge straight into cold, nutrient-rich marine ecosystems. In 2026, this extreme wilderness is experiencing a renaissance of scientific travel and high-end sustainable tourism.</p>
      
      <h2>Conscious Travel and Low-Impact Cruises</h2>
      <p>Traditional heavy cruise liners are giving way to boutique expedition ships powered by hybrid electric propulsion systems. These vessels travel silently, producing minimal acoustic disturbance to critical cetacean migratory lanes where blue whales and orcas feed.</p>
      
      <h2>Preservation by Indigenous Communities</h2>
      <p>Conservation efforts have found their most effective champions in the Kawésqar communities. Armed with marine monitoring applications, local tribes work directly with international oceanographers to identify warming currents and track kelp forest health.</p>
      <blockquote>"We do not own these waters; we are their guardians. If the fjords warm, the global ocean loses its respiratory lungs." — José Aguayo, Community Elder</blockquote>
    `
  },
  {
    id: 4,
    title: "Unveiling the Next Era of Wearable Bio-Sensors for Preventive Health",
    excerpt: "New non-invasive micro-needle patches track real-time metabolic markers, empowering individuals to manage health conditions before symptoms present.",
    category: "Health",
    author: "Dr. Robert Chen",
    authorAvatar: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150",
    authorBio: "Clinical health researcher and advisor specializing in bio-telemetry, nutrition science, and diagnostics.",
    date: "May 07, 2026",
    readTime: "5 min read",
    image: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800",
    views: 14230,
    trending: true,
    editorsPick: true,
    content: `
      <p>Imagine knowing your blood glucose, lactate, and cortisol levels dynamically throughout the day without ever drawing a single drop of blood. In 2026, this scenario is no longer future-talk: wearable micro-needle arrays are officially clearing health regulatory pipelines.</p>
      
      <h2>Decoding Metabolic Health in Real-Time</h2>
      <p>These paper-thin patches adhere comfortably to the upper arm. Using tiny bio-sensors, they measure molecules in the interstitial fluid. The data is transmitted via encrypted Bluetooth to an on-device application, translating complex chemical feedback into customized nutritional and activity guidance.</p>
      
      <h2>Shifting from Treatment to Intervention</h2>
      <p>For decades, public healthcare has been reactive—treating diseases once symptoms arise. Bio-wearables allow for immediate prevention. An elevated cortisol baseline paired with sliding glucose tolerances can alert users to prioritize sleep or adjust diet weeks before chronic fatigue set in.</p>
    `
  },
  {
    id: 5,
    title: "How Modern Sports Sciences are Extending Careers Beyond Forty",
    excerpt: "Thanks to deep muscular-skeletal simulation and targeted nutritional bio-hacking, modern super-athletes are dominating world podiums past their prime.",
    category: "Sports",
    author: "Marcus Vance",
    authorAvatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150",
    authorBio: "Ex-athlete and sports performance consultant specializing in recovery methodologies and biomechanics.",
    date: "May 05, 2026",
    readTime: "4 min read",
    image: "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800",
    views: 8900,
    trending: false,
    editorsPick: false,
    content: `
      <p>The image of a professional athlete retiring in their early thirties is obsolete. In the current global sports arenas, superstars in their early forties are securing Olympic medals and lifting championship trophies, challenging our understanding of biological thresholds.</p>
      
      <h2>AI-Guided Mechanical Correction</h2>
      <p>Using high-speed camera feeds and deep learning biomechanical models, sports therapists can diagnose minuscule mechanical anomalies. Adjusting a running gait by two degrees can save the meniscus and hips from thousands of pounds of unnecessary stress over a season.</p>
      
      <h2>Cold-Laser and Stem-Cell Therapy Advancements</h2>
      <p>Micro-tears that once sidelined athletes for weeks are now targeted with localized hyperbaric oxygen chambers and low-level laser therapies, accelerating soft-tissue recovery by double-digit speeds.</p>
    `
  },
  {
    id: 6,
    title: "Independent Cinema Surpasses Big-Budget Studios in Streaming Era",
    excerpt: "With distributed production tools and decentralized funding models, art-house filmmakers are dominating viewership indices worldwide.",
    category: "Entertainment",
    author: "Chloe Dubois",
    authorAvatar: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150",
    authorBio: "Independent film critic, screenwriting coach, and expert on subscription entertainment ecosystems.",
    date: "May 04, 2026",
    readTime: "5 min read",
    image: "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800",
    views: 11050,
    trending: false,
    editorsPick: false,
    content: `
      <p>A paradigm shift is occurring in how movies are conceptualized, funded, and watched. The classic Hollywood studio structure is facing severe disruption as nimble, independent creators leverage open collaboration software and direct-to-audience subscription channels.</p>
      
      <h2>The Power of Global Collaboration Platforms</h2>
      <p>In 2026, a director based in Paris can coordinate color grading with a specialist in Seoul and sound design with an engineer in London in real-time over high-speed cloud pipelines, lowering overhead costs dramatically.</p>
      
      <h2>Crowdfunded IP Governance</h2>
      <p>Rather than yielding artistic control to massive media networks, filmmakers are selling fractional ownership of digital release rights directly to fans. This ensures dedicated financial support and a built-in promotional base from day one.</p>
    `
  }
];

// Initialize or retrieve active articles database
let articlesDb = JSON.parse(localStorage.getItem('herald_articles'));
if (!articlesDb || articlesDb.length === 0) {
  articlesDb = DEFAULT_ARTICLES;
  localStorage.setItem('herald_articles', JSON.stringify(articlesDb));
}

// Centralized Storage Syncer
function syncDatabase() {
  localStorage.setItem('herald_articles', JSON.stringify(articlesDb));
}

// Navigation helpers
const categoryColors = {
  "Technology": "tech",
  "World": "world",
  "Business": "business",
  "Sports": "sports",
  "Entertainment": "entertainment",
  "Health": "health"
};

document.addEventListener('DOMContentLoaded', () => {
  // Initialize core UI mechanisms
  initTheme();
  initMobileMenu();
  initStickyHeader();
  initSearch();
  initScrollTop();
  initCookieConsent();
  initNewsletterPopup();
  
  // Render modules according to active DOM presence
  if (document.getElementById('hero-carousel')) {
    initCarousel();
    renderHomepageArticles();
  }
  if (document.getElementById('article-page-container')) {
    renderArticleDetailPage();
  }
  if (document.getElementById('category-page-container')) {
    renderCategoryPage();
  }
  if (document.getElementById('contact-form')) {
    initContactForm();
  }
  if (document.getElementById('admin-panel-container')) {
    initAdminCMS();
  }
});

/* --------------------------------------------------------------------------
   THEME MODULE (Dark / Light Mode Toggle)
   -------------------------------------------------------------------------- */
function initTheme() {
  const themeToggle = document.getElementById('theme-toggle');
  if (!themeToggle) return;
  
  const savedTheme = localStorage.getItem('theme');
  const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
  
  if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
    document.documentElement.setAttribute('data-theme', 'dark');
    themeToggle.innerHTML = '☀️';
  } else {
    document.documentElement.setAttribute('data-theme', 'light');
    themeToggle.innerHTML = '🌙';
  }
  
  themeToggle.addEventListener('click', () => {
    const currentTheme = document.documentElement.getAttribute('data-theme');
    let newTheme = 'light';
    
    if (currentTheme === 'light') {
      newTheme = 'dark';
      themeToggle.innerHTML = '☀️';
    } else {
      themeToggle.innerHTML = '🌙';
    }
    
    document.documentElement.setAttribute('data-theme', newTheme);
    localStorage.setItem('theme', newTheme);
  });
}

/* --------------------------------------------------------------------------
   MOBILE NAVIGATION & OVERLAY MENU
   -------------------------------------------------------------------------- */
function initMobileMenu() {
  const menuToggle = document.getElementById('menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');
  const mobileClose = document.getElementById('mobile-close');
  const overlay = document.getElementById('overlay');
  
  if (!menuToggle || !mobileNav || !mobileClose || !overlay) return;
  
  function openMenu() {
    mobileNav.classList.add('open');
    overlay.classList.add('active');
    document.body.style.overflow = 'hidden';
  }
  
  function closeMenu() {
    mobileNav.classList.remove('open');
    overlay.classList.remove('active');
    document.body.style.overflow = '';
  }
  
  menuToggle.addEventListener('click', openMenu);
  mobileClose.addEventListener('click', closeMenu);
  overlay.addEventListener('click', closeMenu);
  
  const mobileLinks = mobileNav.querySelectorAll('a');
  mobileLinks.forEach(link => {
    link.addEventListener('click', closeMenu);
  });
}

/* --------------------------------------------------------------------------
   STICKY NAV ON SCROLL
   -------------------------------------------------------------------------- */
function initStickyHeader() {
  const header = document.querySelector('header');
  if (!header) return;
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 50) {
      header.classList.add('sticky');
    } else {
      header.classList.remove('sticky');
    }
  });
}

/* --------------------------------------------------------------------------
   SEARCH MODULE
   -------------------------------------------------------------------------- */
function initSearch() {
  const searchBtn = document.getElementById('search-btn');
  const searchContainer = document.getElementById('search-container');
  const searchInput = document.getElementById('search-input');
  
  if (!searchBtn || !searchContainer || !searchInput) return;
  
  searchBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    searchContainer.classList.toggle('active');
    if (searchContainer.classList.contains('active')) {
      searchInput.focus();
    }
  });
  
  document.addEventListener('click', (e) => {
    if (!searchContainer.contains(e.target)) {
      searchContainer.classList.remove('active');
    }
  });
  
  searchInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
      const query = searchInput.value.trim();
      if (query) {
        window.location.href = `category.html?search=${encodeURIComponent(query)}`;
      }
    }
  });
}

/* --------------------------------------------------------------------------
   SCROLL TO TOP BUTTON
   -------------------------------------------------------------------------- */
function initScrollTop() {
  const scrollTopBtn = document.getElementById('scroll-top');
  if (!scrollTopBtn) return;
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
      scrollTopBtn.classList.add('active');
    } else {
      scrollTopBtn.classList.remove('active');
    }
  });
  
  scrollTopBtn.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
}

/* --------------------------------------------------------------------------
   COOKIE CONSENT BANNER
   -------------------------------------------------------------------------- */
function initCookieConsent() {
  const cookieBanner = document.getElementById('cookie-consent');
  const acceptBtn = document.getElementById('cookie-accept');
  const declineBtn = document.getElementById('cookie-decline');
  
  if (!cookieBanner || !acceptBtn || !declineBtn) return;
  
  const cookieResponse = localStorage.getItem('cookieConsent');
  if (!cookieResponse) {
    setTimeout(() => {
      cookieBanner.classList.add('show');
    }, 2000);
  }
  
  acceptBtn.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'accepted');
    cookieBanner.classList.remove('show');
  });
  
  declineBtn.addEventListener('click', () => {
    localStorage.setItem('cookieConsent', 'declined');
    cookieBanner.classList.remove('show');
  });
}

/* --------------------------------------------------------------------------
   NEWSLETTER SIGNUP POPUP
   -------------------------------------------------------------------------- */
function initNewsletterPopup() {
  const popup = document.getElementById('newsletter-popup');
  const closeBtn = document.getElementById('popup-close');
  const popupForm = document.getElementById('popup-newsletter-form');
  
  if (!popup || !closeBtn) return;
  
  const popupShown = sessionStorage.getItem('newsletterPopupShown');
  
  if (!popupShown) {
    setTimeout(() => {
      showPopup();
    }, 25000);
    
    window.addEventListener('scroll', triggerOnScroll);
  }
  
  function triggerOnScroll() {
    const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
    if (window.scrollY > scrollHeight / 2) {
      showPopup();
      window.removeEventListener('scroll', triggerOnScroll);
    }
  }
  
  function showPopup() {
    popup.classList.add('show');
    sessionStorage.setItem('newsletterPopupShown', 'true');
  }
  
  function closePopup() {
    popup.classList.remove('show');
  }
  
  closeBtn.addEventListener('click', closePopup);
  popup.addEventListener('click', (e) => {
    if (e.target === popup) {
      closePopup();
    }
  });
  
  if (popupForm) {
    popupForm.addEventListener('submit', (e) => {
      e.preventDefault();
      const emailInput = popupForm.querySelector('input[type="email"]');
      if (emailInput.value.trim()) {
        alert(`Thank you for subscribing! We've sent a verification link to ${emailInput.value.trim()}.`);
        emailInput.value = '';
        closePopup();
      }
    });
  }
}

/* --------------------------------------------------------------------------
   HOMEPAGE ARTICLE SLIDER / CAROUSEL
   -------------------------------------------------------------------------- */
let slideIndex = 0;
let slideInterval;

function initCarousel() {
  const container = document.getElementById('hero-carousel');
  if (!container) return;
  
  // Select articles marked as Editors Pick
  const featuredArticles = articlesDb.filter(art => art.editorsPick).slice(0, 3);
  
  if (featuredArticles.length === 0) {
    // fallback if no editor picks exist
    container.innerHTML = `
      <div class="slide active">
        <div class="slide-overlay" style="justify-content: center; text-align: center;">
          <h2 class="slide-title">No Featured Articles Available</h2>
          <p class="slide-excerpt">Use the Admin Portal to mark articles as Editor's Picks!</p>
          <a href="admin.html" class="btn-primary" style="align-self: center;">Go to Admin CMS</a>
        </div>
      </div>
    `;
    return;
  }

  let slideHTML = '';
  featuredArticles.forEach((art, idx) => {
    const badgeClass = categoryColors[art.category] || '';
    slideHTML += `
      <div class="slide ${idx === 0 ? 'active' : ''}" data-slide-index="${idx}">
        <img src="${art.image}" alt="${art.title}" class="slide-img" loading="eager">
        <div class="slide-overlay">
          <div class="slide-meta">
            <span class="badge ${badgeClass}">${art.category}</span>
            <span class="slide-time">${art.date}</span>
          </div>
          <h2 class="slide-title"><a href="article.html?id=${art.id}">${art.title}</a></h2>
          <p class="slide-excerpt">${art.excerpt}</p>
          <a href="article.html?id=${art.id}" class="btn-primary">Read Full Article</a>
        </div>
      </div>
    `;
  });
  
  container.innerHTML = slideHTML + `
    <div class="carousel-nav">
      <button class="carousel-btn" id="prev-slide" aria-label="Previous slide">←</button>
      <button class="carousel-btn" id="next-slide" aria-label="Next slide">→</button>
    </div>
  `;
  
  startSlideShow();
  
  document.getElementById('prev-slide').addEventListener('click', () => {
    changeSlide(-1);
    resetSlideShow();
  });
  
  document.getElementById('next-slide').addEventListener('click', () => {
    changeSlide(1);
    resetSlideShow();
  });
}

function changeSlide(direction) {
  const slides = document.querySelectorAll('.slide');
  if (!slides.length) return;
  
  slides[slideIndex].classList.remove('active');
  
  slideIndex += direction;
  if (slideIndex >= slides.length) {
    slideIndex = 0;
  } else if (slideIndex < 0) {
    slideIndex = slides.length - 1;
  }
  
  slides[slideIndex].classList.add('active');
}

function startSlideShow() {
  slideInterval = setInterval(() => {
    changeSlide(1);
  }, 6500);
}

function resetSlideShow() {
  clearInterval(slideInterval);
  startSlideShow();
}

/* --------------------------------------------------------------------------
   HOMEPAGE POPULATORS (Latest Grid, Trending, Editor's Picks)
   -------------------------------------------------------------------------- */
function renderHomepageArticles() {
  // 1. Ticker Breaking News Content
  const tickerList = document.getElementById('ticker-list');
  if (tickerList) {
    let tickerHTML = '';
    // Show newest 4 articles
    const tickerArticles = [...articlesDb].slice(-4).reverse();
    tickerArticles.forEach(art => {
      tickerHTML += `
        <div class="ticker-item">
          <span>[${art.category.toUpperCase()}]</span> 
          <a href="article.html?id=${art.id}">${art.title}</a>
        </div>
      `;
    });
    tickerList.innerHTML = tickerHTML;
  }
  
  // 2. Hero Sidebar Trending Section
  const trendingBox = document.getElementById('trending-box');
  if (trendingBox) {
    const trendingArticles = [...articlesDb].sort((a, b) => b.views - a.views).slice(0, 5);
    let trendingHTML = '';
    trendingArticles.forEach((art, idx) => {
      trendingHTML += `
        <div class="trending-item">
          <div class="trending-number">0${idx + 1}</div>
          <div class="trending-info">
            <h4 class="trending-title"><a href="article.html?id=${art.id}">${art.title}</a></h4>
            <div class="trending-meta">${art.category} • ${art.readTime}</div>
          </div>
        </div>
      `;
    });
    trendingBox.innerHTML = trendingHTML;
  }

  // 3. Latest News Grid
  const latestGrid = document.getElementById('latest-news-grid');
  if (latestGrid) {
    let latestHTML = '';
    // Show latest reverse order
    const displayArticles = [...articlesDb].reverse();
    displayArticles.forEach(art => {
      const badgeClass = categoryColors[art.category] || '';
      latestHTML += `
        <article class="card">
          <div class="card-img-wrap">
            <img src="${art.image}" alt="${art.title}" class="card-img" loading="lazy">
            <span class="card-badge badge ${badgeClass}">${art.category}</span>
          </div>
          <div class="card-body">
            <div class="card-meta">
              <span class="card-meta-author">${art.author}</span>
              <span>•</span>
              <span>${art.date}</span>
            </div>
            <h3 class="card-title"><a href="article.html?id=${art.id}">${art.title}</a></h3>
            <p class="card-excerpt">${art.excerpt}</p>
            <div class="card-footer">
              <span>${art.readTime}</span>
              <a href="article.html?id=${art.id}" class="read-more">Read Article →</a>
            </div>
          </div>
        </article>
      `;
    });
    latestGrid.innerHTML = latestHTML;
  }

  // 4. Editors Picks Grid
  const editorsGrid = document.getElementById('editors-picks-grid');
  if (editorsGrid) {
    const editorsList = articlesDb.filter(art => art.editorsPick).slice(0, 3);
    let editorsHTML = '';
    editorsList.forEach(art => {
      const badgeClass = categoryColors[art.category] || '';
      editorsHTML += `
        <div class="card-row">
          <div class="card-img-wrap">
            <img src="${art.image}" alt="${art.title}" class="card-img" loading="lazy">
          </div>
          <div class="card-body">
            <span class="badge ${badgeClass}" style="align-self: flex-start; margin-bottom: 0.75rem;">${art.category}</span>
            <h3 class="card-title" style="font-size: 1.25rem;"><a href="article.html?id=${art.id}">${art.title}</a></h3>
            <p class="card-excerpt" style="font-size: 0.85rem; margin-bottom: 0.75rem;">${art.excerpt}</p>
            <div class="card-meta" style="margin-bottom: 0;">
              <span>By ${art.author}</span>
              <span>•</span>
              <span>${art.date}</span>
            </div>
          </div>
        </div>
      `;
    });
    
    if (editorsHTML === '') {
      editorsHTML = `<p style="grid-column: 1/-1; text-align: center; color: var(--text-muted); padding: 2rem;">No Editor's Choices selected yet. Visit the Admin Portal to configure choices.</p>`;
    }
    editorsGrid.innerHTML = editorsHTML;
  }
}

/* --------------------------------------------------------------------------
   ARTICLE DETAIL RENDERING & ROUTING SYSTEM
   -------------------------------------------------------------------------- */
function renderArticleDetailPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const articleId = parseInt(urlParams.get('id')) || 1;
  
  const article = articlesDb.find(art => art.id === articleId);
  
  if (!article) {
    document.getElementById('article-page-content').innerHTML = `
      <div class="text-center section-padding">
        <h2>Oops! Article Not Found</h2>
        <p style="margin: 1.5rem 0;">The article you are trying to access does not exist or has been archived.</p>
        <a href="index.html" class="btn-primary">Back to Homepage</a>
      </div>
    `;
    return;
  }
  
  // Increment Mock View Count on load
  article.views = (article.views || 0) + 1;
  syncDatabase();

  // Dynamic page title (SEO enhancement)
  document.title = `${article.title} - Herald News`;
  
  const container = document.getElementById('article-page-content');
  if (!container) return;
  
  const badgeClass = categoryColors[article.category] || '';
  
  container.innerHTML = `
    <article class="article-detail-wrapper">
      <header class="article-header">
        <span class="badge ${badgeClass}">${article.category}</span>
        <h1 class="article-title-main">${article.title}</h1>
        
        <div class="article-author-meta">
          <div class="author-profile-box">
            <img src="${article.authorAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}" alt="${article.author}" class="author-avatar">
            <div>
              <div class="author-info-name">By ${article.author}</div>
              <div class="author-info-date">Published on ${article.date} • ${article.readTime} • 👁️ ${article.views} views</div>
            </div>
          </div>
          
          <div class="social-share-bar">
            <a href="https://facebook.com" target="_blank" class="share-btn fb" aria-label="Share on Facebook">f</a>
            <a href="https://twitter.com" target="_blank" class="share-btn tw" aria-label="Share on Twitter">t</a>
            <a href="https://linkedin.com" target="_blank" class="share-btn ln" aria-label="Share on LinkedIn">in</a>
            <a href="https://whatsapp.com" target="_blank" class="share-btn wa" aria-label="Share on WhatsApp">w</a>
          </div>
        </div>
      </header>
      
      <img src="${article.image}" alt="${article.title}" class="article-featured-image" loading="eager">
      
      <!-- Table of Contents -->
      <nav class="table-of-contents" aria-label="Table of contents">
        <div class="toc-title">📌 Table of Contents</div>
        <ul class="toc-list">
          <li><a href="#sec-1" class="toc-link">Overview and Editorial Analysis</a></li>
          <li><a href="#sec-2" class="toc-link">Key Developments and Context</a></li>
        </ul>
      </nav>
      
      <!-- Google AdSense In-Article Ad Placement -->
      <div class="ad-container">
        <div class="ad-slot-in-article">
          <div class="ad-placeholder-box"><!-- Google AdSense Ad Slot --> In-Article Banner Responsive Ad</div>
        </div>
      </div>
      
      <div class="article-body-text">
        <div id="sec-1"></div>
        ${article.content}
      </div>
      
      <!-- Article Tags -->
      <div class="article-tags">
        <span class="article-tags-label">Tags:</span>
        <a href="category.html?cat=${article.category.toLowerCase()}" class="tag-item">${article.category}</a>
        <a href="#" class="tag-item">Editorial</a>
        <a href="#" class="tag-item">Analysis</a>
      </div>
      
      <!-- Author Box Profile -->
      <section class="author-profile-card" aria-label="About the author">
        <img src="${article.authorAvatar || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}" alt="${article.author}" class="author-card-avatar">
        <div>
          <h3 class="author-card-name">${article.author}</h3>
          <p class="author-card-bio">${article.authorBio || 'Staff writer specializing in current affairs, industry news, and research analyses.'}</p>
        </div>
      </section>
    </article>
  `;
  
  renderRelatedPosts(article);
  initCommentSubmission();
}

function renderRelatedPosts(currentArticle) {
  const relatedGrid = document.getElementById('related-posts-grid');
  if (!relatedGrid) return;
  
  const related = articlesDb
    .filter(art => art.category === currentArticle.category && art.id !== currentArticle.id)
    .slice(0, 3);
    
  if (related.length < 3) {
    const additional = articlesDb
      .filter(art => art.id !== currentArticle.id && !related.includes(art))
      .slice(0, 3 - related.length);
    related.push(...additional);
  }
  
  let relatedHTML = '';
  related.forEach(art => {
    const badgeClass = categoryColors[art.category] || '';
    relatedHTML += `
      <div class="card">
        <div class="card-img-wrap">
          <img src="${art.image}" alt="${art.title}" class="card-img" loading="lazy">
        </div>
        <div class="card-body" style="padding: 1.25rem;">
          <span class="badge ${badgeClass}" style="align-self: flex-start; margin-bottom: 0.5rem; font-size: 0.65rem;">${art.category}</span>
          <h4 class="card-title" style="font-size: 1.05rem; margin-bottom: 0.5rem;"><a href="article.html?id=${art.id}">${art.title}</a></h4>
          <div class="card-meta" style="margin-bottom: 0; font-size: 0.7rem;">
            <span>${art.date}</span>
          </div>
        </div>
      </div>
    `;
  });
  
  relatedGrid.innerHTML = relatedHTML;
}

function initCommentSubmission() {
  const commentForm = document.getElementById('post-comment-form');
  const commentList = document.getElementById('comment-list-container');
  
  if (!commentForm || !commentList) return;
  
  commentForm.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('comment-name').value.trim();
    const email = document.getElementById('comment-email').value.trim();
    const text = document.getElementById('comment-text').value.trim();
    
    if (!name || !email || !text) {
      alert('Please fill in all fields to submit a comment.');
      return;
    }
    
    const newComment = document.createElement('div');
    newComment.className = 'comment-item';
    newComment.innerHTML = `
      <img src="https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150" alt="${name}" class="comment-avatar">
      <div class="comment-content">
        <div class="comment-header">
          <h4 class="comment-author-name">${name}</h4>
          <span class="comment-date">Today at ${new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
        </div>
        <p class="comment-text">${text}</p>
      </div>
    `;
    
    commentList.appendChild(newComment);
    commentForm.reset();
    
    const countBadge = document.getElementById('comments-count-badge');
    if (countBadge) {
      const count = parseInt(countBadge.innerText) || 0;
      countBadge.innerText = count + 1;
    }
  });
}

/* --------------------------------------------------------------------------
   CATEGORY RENDERING ENGINE
   -------------------------------------------------------------------------- */
function renderCategoryPage() {
  const urlParams = new URLSearchParams(window.location.search);
  const catParam = urlParams.get('cat');
  const searchParam = urlParams.get('search');
  
  const categoryTitle = document.getElementById('category-title');
  const categoryBreadcrumb = document.getElementById('category-breadcrumb');
  const gridContainer = document.getElementById('category-grid-container');
  
  if (!gridContainer || !categoryTitle) return;
  
  let filteredArticles = [];
  let titleText = "Category Archives";
  let breadcrumbText = "All Articles";
  
  if (catParam) {
    const targetCat = catParam.toLowerCase();
    filteredArticles = articlesDb.filter(art => art.category.toLowerCase() === targetCat);
    titleText = targetCat.charAt(0).toUpperCase() + targetCat.slice(1);
    breadcrumbText = titleText;
  } else if (searchParam) {
    const targetQuery = searchParam.toLowerCase();
    filteredArticles = articlesDb.filter(art => 
      art.title.toLowerCase().includes(targetQuery) || 
      art.excerpt.toLowerCase().includes(targetQuery) || 
      art.content.toLowerCase().includes(targetQuery)
    );
    titleText = `Search Results for "${searchParam}"`;
    breadcrumbText = "Search";
  } else {
    filteredArticles = articlesDb;
    titleText = "Explore Articles";
    breadcrumbText = "All Categories";
  }
  
  categoryTitle.innerText = titleText;
  if (categoryBreadcrumb) {
    categoryBreadcrumb.innerText = breadcrumbText;
  }
  
  if (filteredArticles.length === 0) {
    gridContainer.innerHTML = `
      <div class="text-center section-padding" style="grid-column: 1 / -1;">
        <h2>No Articles Found</h2>
        <p style="margin: 1.5rem 0;">We couldn't find any articles matching your criteria. Please try searching or browse other categories.</p>
        <a href="index.html" class="btn-primary">Back to Home</a>
      </div>
    `;
    return;
  }
  
  let html = '';
  // show in reverse order (latest first)
  [...filteredArticles].reverse().forEach(art => {
    const badgeClass = categoryColors[art.category] || '';
    html += `
      <article class="card">
        <div class="card-img-wrap">
          <img src="${art.image}" alt="${art.title}" class="card-img" loading="lazy">
          <span class="card-badge badge ${badgeClass}">${art.category}</span>
        </div>
        <div class="card-body">
          <div class="card-meta">
            <span class="card-meta-author">${art.author}</span>
            <span>•</span>
            <span>${art.date}</span>
          </div>
          <h3 class="card-title"><a href="article.html?id=${art.id}">${art.title}</a></h3>
          <p class="card-excerpt">${art.excerpt}</p>
          <div class="card-footer">
            <span>${art.readTime}</span>
            <a href="article.html?id=${art.id}" class="read-more">Read Article →</a>
          </div>
        </div>
      </article>
    `;
  });
  
  gridContainer.innerHTML = html;
}

/* --------------------------------------------------------------------------
   CONTACT FORM VALIDATION
   -------------------------------------------------------------------------- */
function initContactForm() {
  const form = document.getElementById('contact-form');
  if (!form) return;
  
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    
    const name = document.getElementById('contact-name').value.trim();
    const email = document.getElementById('contact-email').value.trim();
    const subject = document.getElementById('contact-subject').value.trim();
    const message = document.getElementById('contact-message').value.trim();
    
    if (!name || !email || !subject || !message) {
      alert('Please fill in all required fields.');
      return;
    }
    
    alert(`Thank you, ${name}! Your message regarding "${subject}" has been sent successfully. We will get back to you within 24-48 hours.`);
    form.reset();
  });
}

/* --------------------------------------------------------------------------
   ADMIN CMS PANEL ENGINE (Add / Edit / Delete News Portal)
   -------------------------------------------------------------------------- */
let editingArticleId = null;

function initAdminCMS() {
  renderAdminTable();
  renderAdminStats();
  
  const articleForm = document.getElementById('admin-article-form');
  const cancelEditBtn = document.getElementById('cancel-edit-btn');
  
  if (articleForm) {
    articleForm.addEventListener('submit', (e) => {
      e.preventDefault();
      saveArticleFromForm();
    });
  }
  
  if (cancelEditBtn) {
    cancelEditBtn.addEventListener('click', () => {
      resetAdminForm();
    });
  }
}

function renderAdminStats() {
  const statTotal = document.getElementById('stat-total-articles');
  const statViews = document.getElementById('stat-total-views');
  const statFeatured = document.getElementById('stat-total-featured');
  
  if (statTotal) statTotal.innerText = articlesDb.length;
  
  if (statViews) {
    const totalViews = articlesDb.reduce((acc, cur) => acc + (cur.views || 0), 0);
    statViews.innerText = totalViews.toLocaleString();
  }
  
  if (statFeatured) {
    const featuredCount = articlesDb.filter(art => art.editorsPick).length;
    statFeatured.innerText = featuredCount;
  }
}

function renderAdminTable() {
  const tbody = document.getElementById('admin-articles-tbody');
  if (!tbody) return;
  
  let html = '';
  // show latest articles first
  [...articlesDb].reverse().forEach((art) => {
    html += `
      <tr>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); font-weight: 600;">#${art.id}</td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color);">
          <img src="${art.image}" alt="" style="width: 50px; height: 35px; object-fit: cover; border-radius: 4px;">
        </td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); font-weight: 700;">${art.title}</td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color);"><span class="badge ${categoryColors[art.category] || ''}">${art.category}</span></td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); font-size: 0.85rem; color: var(--text-secondary);">${art.author}</td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); font-size: 0.85rem;">${art.date}</td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); text-align: center;">${art.editorsPick ? '✅ Yes' : '❌ No'}</td>
        <td style="padding: 1rem; border-bottom: 1px solid var(--border-color); text-align: right;">
          <button onclick="triggerEditArticle(${art.id})" class="btn-primary" style="padding: 0.3rem 0.7rem; font-size: 0.75rem; background-color: #0284c7; margin-right: 0.25rem;">Edit</button>
          <button onclick="triggerDeleteArticle(${art.id})" class="btn-primary" style="padding: 0.3rem 0.7rem; font-size: 0.75rem; background-color: #b91c1c;">Delete</button>
        </td>
      </tr>
    `;
  });
  
  if (articlesDb.length === 0) {
    html = `<tr><td colspan="8" style="text-align: center; padding: 2rem; color: var(--text-muted);">No articles exist. Create the first article above!</td></tr>`;
  }
  
  tbody.innerHTML = html;
}

// Make functions globally available for inline onclick triggers
window.triggerDeleteArticle = function(id) {
  if (!confirm("Are you absolutely sure you want to delete this article? This action cannot be undone.")) return;
  
  articlesDb = articlesDb.filter(art => art.id !== id);
  syncDatabase();
  renderAdminTable();
  renderAdminStats();
  
  // reset form if we deleted the article currently being edited
  if (editingArticleId === id) {
    resetAdminForm();
  }
  
  alert("Article deleted successfully.");
};

window.triggerEditArticle = function(id) {
  const art = articlesDb.find(a => a.id === id);
  if (!art) return;
  
  editingArticleId = id;
  
  // populate form fields
  document.getElementById('form-title').value = art.title;
  document.getElementById('form-category').value = art.category;
  document.getElementById('form-author').value = art.author;
  document.getElementById('form-image').value = art.image;
  document.getElementById('form-excerpt').value = art.excerpt;
  document.getElementById('form-content').value = art.content;
  document.getElementById('form-editors-pick').checked = !!art.editorsPick;
  
  // Change submit button label and reveal cancel button
  document.getElementById('submit-form-btn').innerText = "Update Published Article";
  document.getElementById('cancel-edit-btn').classList.remove('hidden');
  document.getElementById('form-heading-text').innerText = `✏️ Edit Article #${id}`;
  
  // Scroll form into view smoothly
  document.getElementById('admin-form-section').scrollIntoView({ behavior: 'smooth' });
};

function saveArticleFromForm() {
  const title = document.getElementById('form-title').value.trim();
  const category = document.getElementById('form-category').value;
  const author = document.getElementById('form-author').value.trim();
  const imageInput = document.getElementById('form-image').value.trim();
  const excerpt = document.getElementById('form-excerpt').value.trim();
  const content = document.getElementById('form-content').value.trim();
  const editorsPick = document.getElementById('form-editors-pick').checked;
  
  if (!title || !category || !author || !excerpt || !content) {
    alert("Please fill in all mandatory fields.");
    return;
  }
  
  // Safe fallback images
  const defaultImages = {
    "Technology": "https://images.unsplash.com/photo-1677442136019-21780efad99a?w=800",
    "World": "https://images.unsplash.com/photo-1504280390367-361c6d9f38f4?w=800",
    "Business": "https://images.unsplash.com/photo-1473341304170-971dccb5ac1e?w=800",
    "Sports": "https://images.unsplash.com/photo-1517838277536-f5f99be501cd?w=800",
    "Entertainment": "https://images.unsplash.com/photo-1489599849927-2ee91cede3ba?w=800",
    "Health": "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800"
  };
  const image = imageInput || defaultImages[category] || "https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800";
  
  const dateOptions = { month: 'short', day: 'numeric', year: 'numeric' };
  const dateStr = new Date().toLocaleDateString('en-US', dateOptions);
  
  // Calculate estimated reading time (roughly 200 words per minute)
  const words = (content + excerpt).split(/\s+/).length;
  const readTimeVal = Math.max(1, Math.ceil(words / 200));
  const readTime = `${readTimeVal} min read`;
  
  if (editingArticleId !== null) {
    // Update Mode
    const artIndex = articlesDb.findIndex(a => a.id === editingArticleId);
    if (artIndex !== -1) {
      articlesDb[artIndex] = {
        ...articlesDb[artIndex],
        title,
        category,
        author,
        image,
        excerpt,
        content,
        editorsPick,
        readTime
      };
      alert("Article updated and synchronized successfully!");
    }
  } else {
    // Create Mode
    const nextId = articlesDb.length > 0 ? Math.max(...articlesDb.map(a => a.id)) + 1 : 1;
    const newArt = {
      id: nextId,
      title,
      category,
      author,
      authorAvatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150", // Generic Avatar
      authorBio: `Staff editor writing in the ${category} sector.`,
      date: dateStr,
      readTime,
      image,
      views: 0,
      trending: false,
      editorsPick,
      content
    };
    
    articlesDb.push(newArt);
    alert("New article published successfully!");
  }
  
  syncDatabase();
  resetAdminForm();
  renderAdminTable();
  renderAdminStats();
}

function resetAdminForm() {
  editingArticleId = null;
  document.getElementById('admin-article-form').reset();
  
  document.getElementById('submit-form-btn').innerText = "Publish Article Live";
  document.getElementById('cancel-edit-btn').classList.add('hidden');
  document.getElementById('form-heading-text').innerText = "✍️ Publish a New Article";
}
